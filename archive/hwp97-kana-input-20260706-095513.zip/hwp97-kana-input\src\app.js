const editor = document.querySelector("#editor");
const modeStatus = document.querySelector("#modeStatus");
const bufferStatus = document.querySelector("#bufferStatus");
const copyButton = document.querySelector("#copyButton");
const clearButton = document.querySelector("#clearButton");
const sampleButtons = document.querySelectorAll("[data-sample]");

const ROMAJI_PUNCTUATION = {
  "-": "ー",
  ",": "、",
  ".": "。",
  "?": "？",
  "!": "！",
  "[": "「",
  "]": "」",
  "(": "（",
  ")": "）",
  "/": "・",
};

let romajiBuffer = "";
let isComposing = false;
let isTransforming = false;
let hangulTransformTimer = 0;

function currentScript() {
  return document.querySelector('input[name="script"]:checked').value;
}

function currentScheme() {
  return document.querySelector('input[name="scheme"]:checked').value;
}

function updateStatus() {
  const scriptLabel = currentScript() === "katakana" ? "カタカナ" : "ひらがな";
  const scheme = currentScheme();
  const schemeLabel =
    scheme === "hangul" ? "Hangul Phonetic" : scheme === "jis" ? "JIS Kana" : "Romaji";
  modeStatus.textContent = `${schemeLabel} · ${scriptLabel}`;
  bufferStatus.textContent = romajiBuffer ? `buffer: ${romajiBuffer}` : "";
}

function insertText(text) {
  const start = editor.selectionStart;
  const end = editor.selectionEnd;
  editor.setRangeText(text, start, end, "end");
}

function replacePreviousCharacter(text) {
  const start = editor.selectionStart;
  if (start === 0 || start !== editor.selectionEnd) {
    insertText(text);
    return;
  }
  editor.setRangeText(text, start - 1, start, "end");
}

function flushBuffer() {
  if (!romajiBuffer) {
    return;
  }
  insertText(KanaEngine.flushRomaji(romajiBuffer, currentScript()));
  romajiBuffer = "";
  updateStatus();
}

function cancelScheduledHangulTransform() {
  if (hangulTransformTimer) {
    clearTimeout(hangulTransformTimer);
    hangulTransformTimer = 0;
  }
}

function scheduleHangulTransform(delay = 120) {
  if (currentScheme() !== "hangul") {
    return;
  }

  cancelScheduledHangulTransform();
  hangulTransformTimer = setTimeout(() => {
    hangulTransformTimer = 0;
    if (!isComposing) {
      transformHangulEditor();
    }
  }, delay);
}

function transformHangulEditor() {
  if (isTransforming || currentScheme() !== "hangul") {
    return;
  }

  const value = editor.value;
  const start = editor.selectionStart;
  const end = editor.selectionEnd;
  const converted = KanaEngine.convertHangulPhonetic(value, { script: currentScript() });

  if (converted === value) {
    return;
  }

  const convertedStart = KanaEngine.convertHangulPhonetic(value.slice(0, start), {
    script: currentScript(),
  }).length;
  const convertedEnd = KanaEngine.convertHangulPhonetic(value.slice(0, end), {
    script: currentScript(),
  }).length;

  isTransforming = true;
  editor.value = converted;
  editor.setSelectionRange(convertedStart, convertedEnd);
  isTransforming = false;
}

function handleRomajiInput(key) {
  if (/^[a-zA-Z]$/.test(key) || key === "'") {
    romajiBuffer += key.toLowerCase();
    const converted = KanaEngine.convertRomaji(romajiBuffer, {
      final: false,
      script: currentScript(),
    });
    if (converted.text) {
      insertText(converted.text);
    }
    romajiBuffer = converted.rest;
    updateStatus();
    return true;
  }

  if (Object.prototype.hasOwnProperty.call(ROMAJI_PUNCTUATION, key)) {
    flushBuffer();
    insertText(KanaEngine.convertScript(ROMAJI_PUNCTUATION[key], currentScript()));
    return true;
  }

  if (key === " ") {
    flushBuffer();
    insertText(" ");
    return true;
  }

  return false;
}

function handleJisKanaInput(event) {
  const kana = KanaEngine.jisKanaFromKey(event, currentScript());
  if (!kana) {
    return false;
  }

  if (kana === "゛" || kana === "゜") {
    const start = editor.selectionStart;
    if (start > 0 && start === editor.selectionEnd) {
      const previous = editor.value.slice(start - 1, start);
      const marked = KanaEngine.applyKanaMark(previous, kana, currentScript());
      if (marked.applied) {
        replacePreviousCharacter(marked.text);
        return true;
      }
    }
  }

  insertText(kana);
  return true;
}

editor.addEventListener("keydown", (event) => {
  if (event.ctrlKey || event.altKey || event.metaKey) {
    return;
  }

  if (currentScheme() === "hangul") {
    return;
  }

  if (event.key === "Escape") {
    romajiBuffer = "";
    updateStatus();
    event.preventDefault();
    return;
  }

  if (event.key === "Backspace") {
    if (romajiBuffer) {
      romajiBuffer = romajiBuffer.slice(0, -1);
      updateStatus();
      event.preventDefault();
    }
    return;
  }

  if (event.key === "Enter") {
    flushBuffer();
    insertText("\n");
    event.preventDefault();
    return;
  }

  if (event.key === "Tab") {
    flushBuffer();
    insertText("\t");
    event.preventDefault();
    return;
  }

  const handled =
    currentScheme() === "romaji" ? handleRomajiInput(event.key) : handleJisKanaInput(event);

  if (handled) {
    event.preventDefault();
  }
});

editor.addEventListener("compositionstart", () => {
  isComposing = true;
  cancelScheduledHangulTransform();
});

editor.addEventListener("compositionend", () => {
  isComposing = false;
  scheduleHangulTransform();
});

editor.addEventListener("input", (event) => {
  if (!isComposing && !event.isComposing) {
    scheduleHangulTransform();
  }
});

for (const input of document.querySelectorAll('input[name="script"], input[name="scheme"]')) {
  input.addEventListener("change", () => {
    cancelScheduledHangulTransform();
    flushBuffer();
    transformHangulEditor();
    updateStatus();
    editor.focus();
  });
}

copyButton.addEventListener("click", async () => {
  cancelScheduledHangulTransform();
  flushBuffer();
  transformHangulEditor();
  await navigator.clipboard.writeText(editor.value);
  editor.focus();
});

clearButton.addEventListener("click", () => {
  cancelScheduledHangulTransform();
  editor.value = "";
  romajiBuffer = "";
  updateStatus();
  editor.focus();
});

for (const button of sampleButtons) {
  button.addEventListener("click", () => {
    cancelScheduledHangulTransform();
    flushBuffer();
    editor.value = button.dataset.sample;
    editor.setSelectionRange(editor.value.length, editor.value.length);
    transformHangulEditor();
    editor.focus();
  });
}

updateStatus();
