# HWP97 Kana Input

Windows 11에서 쓸 수 있도록 새로 만든 일본어 가나 입력 프로토타입입니다.

## 실행

`index.html`을 브라우저에서 열면 바로 사용할 수 있습니다.

## 먼저 테스트할 것

기본 입력 방식은 `Hangul`입니다. 한글 IME로 아래처럼 입력해 보세요.

- `와타시` -> `わたし`
- `히라가나` -> `ひらがな`
- `카타카나` + `カタカナ` 모드 -> `カタカナ`
- `신주쿠` -> `しんじゅく`
- `갓코우` -> `がっこう`
- `아리가토우` -> `ありがとう`
- `오하요우` -> `おはよう`
- `쥬-스` -> `じゅーす`

상단 예문 버튼을 누르면 현재 선택된 `ひらがな`/`カタカナ` 모드로 바로 변환됩니다.

## 범위

- 한글 발음 입력을 히라가나 또는 카타카나로 변환합니다.
- Romaji 입력도 보조로 지원합니다.
- JIS kana 직접 입력의 기본 키 배열을 지원합니다.
- 탁음/반탁음 조합을 지원합니다.
- 이 코드는 한글 97의 바이너리나 사전 파일을 재사용하지 않습니다.

## 조사 메모

최신 한컴 도움말에도 일본어 글자판은 남아 있습니다. 공식 문서 기준으로 확인되는 방식은 다음과 같습니다.

- [한컴 도움말: 일본어 글자판](https://help.hancom.com/hoffice130/ko-KR/HncFinder/insert/keyboard/keyboard%28japanese%29.htm)
- [한컴 도움말: 글자판 바꾸기](https://help.hancom.com/hoffice130_assistant/ko-KR/Hwp/insert/keyboard/keyboard%28change%29.htm)
- [한컴 도움말: 동아시아 언어 입력 옵션](https://help.hancom.com/hoffice130_assistant/ko-KR/Hwp/insert/keyboard/keyboard%28asia_option%29.htm)

확인되는 기능은 일본어 직접 글자판, 영어/로마자 발음 입력, 외래어 글자판, 일본어 변환/확정 옵션입니다. 하지만 `와타시` -> `わたし`처럼 한글 발음을 일본어 가나로 바꾸는 방식은 현재 공개 도움말의 일본어 글자판 종류에는 보이지 않습니다.

한컴 외부에서는 비슷한 아이디어가 일부 확인됩니다.

- [Google Play: 한글 발음 일본어 키보드](https://play.google.com/store/apps/details?id=com.studiogmh.kj_keyboard)
- [ONE store: 한글 발음 일본어 입력기](https://m.onestore.co.kr/v2/ko-kr/app/0000201960/about)
- [SoftDowntown: 다울소프트 일본어 입력기](https://www.softdowntown.com/bbs/board.php?bo_table=board&wr_id=1487)
- [한국어닷컴: 일본어 히라가나/가타카나 변환기](https://xn--yq5bk9r.com/blog/korean-to-japanes)

현 단계의 방향은 한글 97 바이너리를 추출하거나 패치하지 않고, 한글97의 사용감에 가까운 한글 발음 기반 일본어 입력을 Windows 11용으로 새로 재현하는 것입니다.

## 테스트

```powershell
node test\kana-engine.test.js
```
