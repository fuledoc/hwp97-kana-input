const assert = require("node:assert/strict");
const KanaEngine = require("../src/kana-engine");

function final(input, script = "hiragana") {
  return KanaEngine.flushRomaji(input, script);
}

function hangul(input, expected, script = "hiragana") {
  assert.equal(KanaEngine.convertHangulPhonetic(input, { script }), expected);
}

assert.equal(final("aiueo"), "あいうえお");
assert.equal(final("kakikukeko"), "かきくけこ");
assert.equal(final("sashisuseso"), "さしすせそ");
assert.equal(final("tachitsuteto"), "たちつてと");
assert.equal(final("konnichiha"), "こんにちは");
assert.equal(final("nihongo"), "にほんご");
assert.equal(final("gakkou"), "がっこう");
assert.equal(final("ryokou"), "りょこう");
assert.equal(final("shinjuku"), "しんじゅく");
assert.equal(final("kon'ya"), "こんや");
assert.equal(final("pa pi pu pe po"), "ぱ ぴ ぷ ぺ ぽ");
assert.equal(final("konnichiha", "katakana"), "コンニチハ");

assert.deepEqual(KanaEngine.convertRomaji("ky", { final: false }), {
  text: "",
  rest: "ky",
});
assert.deepEqual(KanaEngine.convertRomaji("kya", { final: false }), {
  text: "きゃ",
  rest: "",
});
assert.equal(KanaEngine.toKatakana("がっこう"), "ガッコウ");
assert.equal(KanaEngine.toHiragana("ガッコウ"), "がっこう");
assert.deepEqual(KanaEngine.applyKanaMark("か", "゛", "hiragana"), {
  text: "が",
  applied: true,
});
assert.deepEqual(KanaEngine.applyKanaMark("ハ", "゜", "katakana"), {
  text: "パ",
  applied: true,
});
assert.equal(KanaEngine.jisKanaFromKey({ code: "KeyQ", shiftKey: false }, "hiragana"), "た");
assert.equal(KanaEngine.jisKanaFromKey({ code: "Digit3", shiftKey: true }, "hiragana"), "ぁ");
assert.equal(KanaEngine.jisKanaFromKey({ code: "KeyQ", shiftKey: false }, "katakana"), "タ");

hangul("와타시", "わたし");
hangul("히라가나", "ひらがな");
hangul("카타카나", "カタカナ", "katakana");
hangul("신주쿠", "しんじゅく");
hangul("갓코우", "がっこう");
hangul("스시", "すし");
hangul("츠키", "つき");
hangul("아리가토우", "ありがとう");
hangul("오하요우", "おはよう");
hangul("사요우나라", "さようなら");
hangul("니혼고", "にほんご");
hangul("가쿠세이", "がくせい");
hangul("센세이", "せんせい");
hangul("료코우", "りょこう");
hangul("쟈즈", "じゃず");
hangul("쭈", "っじゅ");
hangul("맛차", "まっちゃ");
hangul("랏쿄", "らっきょ");
hangul("후지산", "ふじさん");
hangul("아루바이토", "あるばいと");
hangul("쥬-스", "じゅーす");

console.log("kana-engine tests passed");
